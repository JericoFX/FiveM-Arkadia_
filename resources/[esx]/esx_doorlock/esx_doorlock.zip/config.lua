Config = {}
Config.Locale = 'es'

Config.DoorList = {

	--
	-- Mission Row First Floor
	--

	-- Entrance Doors
	{
		objName = 'prop_strip_door_01',
		objCoords  = {x = 127.9552, y = -1298.503, z = 29.41962},
		textCoords = {x = 127.9552, y = -1298.503, z = 30.41962},
		authorizedJobs = { 'unicorn' },
		locked = false,
		distance = 2.5
	},
	
	{
		objName = 'prop_magenta_door',
		objCoords  = {x = 96.09197, y = -1284.854, z = 29.43878},
		textCoords = {x = 96.09197, y = -1284.854, z = 30.43878},
		authorizedJobs = { 'unicorn' },
		locked = false,
		distance = 2.5
	},
	
	{
		objName = 'v_ilev_roc_door2',
		objCoords  = {x = 99.08321, y = -1293.701, z = 29.41868},
		textCoords = {x = 99.08321, y = -1293.701, z = 30.41868},
		authorizedJobs = { 'unicorn' },
		locked = false,
		distance = 2.5
	},
	
	{
		objName = 'v_ilev_ph_door01',
		objCoords  = {x = 434.747, y = -980.618, z = 30.839},
		textCoords = {x = 434.747, y = -981.50, z = 31.50},
		authorizedJobs = { 'police' },
		locked = false,
		distance = 2.5
	},

	{
		objName = 'v_ilev_ph_door002',
		objCoords  = {x = 434.747, y = -983.215, z = 30.839},
		textCoords = {x = 434.747, y = -982.50, z = 31.50},
		authorizedJobs = { 'police' },
		locked = false,
		distance = 2.5
	},

	-- To locker room & roof
	{
		objName = 'v_ilev_ph_gendoor004',
		objCoords  = {x = 449.698, y = -986.469, z = 30.689},
		textCoords = {x = 450.104, y = -986.388, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Rooftop
	{
		objName = 'v_ilev_gtdoor02',
		objCoords  = {x = 464.361, y = -984.678, z = 43.834},
		textCoords = {x = 464.361, y = -984.050, z = 44.834},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Hallway to roof
	{
		objName = 'v_ilev_arm_secdoor',
		objCoords  = {x = 461.286, y = -985.320, z = 30.839},
		textCoords = {x = 461.50, y = -986.00, z = 31.50},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Armory
	{
		objName = 'v_ilev_arm_secdoor',
		objCoords  = {x = 452.618, y = -982.702, z = 30.689},
		textCoords = {x = 453.079, y = -982.600, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Captain Office
	{
		objName = 'v_ilev_ph_gendoor002',
		objCoords  = {x = 447.238, y = -980.630, z = 30.689},
		textCoords = {x = 447.200, y = -980.010, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- To downstairs (double doors)
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 443.97, y = -989.033, z = 30.6896},
		textCoords = {x = 444.020, y = -989.445, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 445.37, y = -988.705, z = 30.6896},
		textCoords = {x = 445.350, y = -989.445, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	-- 
	-- Mission Row Cells
	--

	-- Main Cells
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 463.815, y = -992.686, z = 24.9149},
		textCoords = {x = 463.30, y = -992.686, z = 25.10},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 1
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 462.381, y = -993.651, z = 24.914},
		textCoords = {x = 461.806, y = -993.308, z = 25.064},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 2
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 462.331, y = -998.152, z = 24.914},
		textCoords = {x = 461.806, y = -998.800, z = 25.064},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 3
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 462.704, y = -1001.92, z = 24.9149},
		textCoords = {x = 461.806, y = -1002.450, z = 25.064},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- To Back
	{
		objName = 'v_ilev_gtdoor',
		objCoords  = {x = 463.478, y = -1003.538, z = 25.005},
		textCoords = {x = 464.00, y = -1003.50, z = 25.50},
		authorizedJobs = { 'police' },
		locked = true
	},
	--- celda nueva 1
	{
		objName = 'v_ilev_gtdoor',
		objCoords  = {x = 467.76, y = -996.42, z = 23.91},
		textCoords = {x = 467.76, y = -996.42, z = 25.20},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 3
	},
	
	--- celda nueva 2
	{
		objName = 'v_ilev_gtdoor',
		objCoords  = {x = 472.08, y = -996.42, z = 23.91},
		textCoords = {x = 472.08, y = -996.42, z = 25.20},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 3
	},
	
	--- celda nueva 3
	{
		objName = 'v_ilev_gtdoor',
		objCoords  = {x = 476.52, y = -996.42, z = 23.91},
		textCoords = {x = 476.52, y = -996.42, z = 25.20},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 3
	},
	
    --- celda nueva 4
	{
		objName = 'v_ilev_gtdoor',
		objCoords  = {x = 480.65, y = -996.42, z = 23.91},
		textCoords = {x = 480.65, y = -996.42, z = 25.20},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 3
	},
	
	---Entrada lateral comisaria
	
	{
		objName = 'v_ilev_rc_door2',
		objCoords  = {x = 445.29, y = -996.85, z = 29.69},
		textCoords = {x = 445.29, y = -996.85, z = 30.9},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},
	
	{
		objName = 'v_ilev_rc_door2',
		objCoords  = {x = 446.6, y = -996.85, z = 29.69},
		textCoords = {x = 446.6, y = -996.85, z = 30.9},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	--
	-- Mission Row Back
	--

	-- Back (double doors)
	{
		objName = 'v_ilev_rc_door2',
		objCoords  = {x = 467.371, y = -1014.452, z = 26.536},
		textCoords = {x = 468.09, y = -1014.452, z = 27.1362},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	{
		objName = 'v_ilev_rc_door2',
		objCoords  = {x = 469.967, y = -1014.452, z = 26.536},
		textCoords = {x = 469.35, y = -1014.452, z = 27.136},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	-- Back Gate
	{
		objName = 'hei_prop_station_gate',
		objCoords  = {x = 488.894, y = -1017.210, z = 27.146},
		textCoords = {x = 488.894, y = -1020.210, z = 30.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 14,
		size = 2
	},

	--
	-- Sandy Shores
	--

	-- Entrance
	{
		objName = 'v_ilev_shrfdoor',
		objCoords  = {x = 1855.105, y = 3683.516, z = 34.266},
		textCoords = {x = 1855.105, y = 3683.516, z = 35.00},
		authorizedJobs = { 'police' },
		locked = false
	},

	--
	-- Paleto Bay
	--

	-- Entrance (double doors)
	{
		objName = 'v_ilev_shrf2door',
		objCoords  = {x = -443.14, y = 6015.685, z = 31.716},
		textCoords = {x = -443.14, y = 6015.685, z = 32.00},
		authorizedJobs = { 'police' },
		locked = false,
		distance = 2.5
	},

	{
		objName = 'v_ilev_shrf2door',
		objCoords  = {x = -443.951, y = 6016.622, z = 31.716},
		textCoords = {x = -443.951, y = 6016.622, z = 32.00},
		authorizedJobs = { 'police' },
		locked = false,
		distance = 2.5
	},

	--
	-- Bolingbroke Penitentiary
	--

	-- Entrance (Two big gates)
	{
		objName = 'prop_gate_prison_01',
		objCoords  = {x = 1844.998, y = 2604.810, z = 44.638},
		textCoords = {x = 1844.998, y = 2608.50, z = 48.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
		size = 2
	},

	{
		objName = 'prop_gate_prison_01',
		objCoords  = {x = 1818.542, y = 2604.812, z = 44.611},
		textCoords = {x = 1818.542, y = 2608.40, z = 48.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
		size = 2
	},

-- Zancudo Military Base Front Entrance
{
	objName = 'prop_gate_airport_01',
	objCoords  = {x = -1587.23, y = 2805.08, z = 15.82},
	textCoords = {x = -1587.23, y = 2805.08, z = 19.82},
	authorizedJobs = { 'merryweather' },
	locked = true,
	distance = 12,
	size = 2
},
{
	objName = 'prop_gate_airport_01',
	objCoords  = {x = -1600.29, y = 2793.74, z = 15.74},
	textCoords = {x = -1600.29, y = 2793.74, z = 19.74},
	authorizedJobs = { 'merryweather' },
	locked = true,
	distance = 12,
	size = 2
},
-- Zancudo Military Base Back Entrance
{
	objName = 'prop_gate_airport_01',
	objCoords  = {x = -2296.17, y = 3393.1, z = 30.07},
	textCoords = {x = -2296.17, y = 3393.1, z = 34.07},
	authorizedJobs = { 'merryweather' },
	locked = true,
	distance = 12,
	size = 2
},
{
	objName = 'prop_gate_airport_01',
	objCoords  = {x = -2306.13, y = 3379.3, z = 30.2},
	textCoords = {x = -2306.13, y = 3379.3, z = 34.2},
	authorizedJobs = { 'merryweather' },
	locked = true,
	distance = 12,
	size = 2
},
-- Paleto Bay Parking Lot Gate
{
	objName = 'prop_gate_airport_01',
	objCoords  = {x = -451.04, y = 6025.31, z = 30.12},
	textCoords = {x = -453.6, y = 6027.87, z = 32.12},
	authorizedJobs = { 'police' },
	locked = true,
	distance = 14,
	size = 2
},
-- Mission Row PD Parking Lot Gate
-- Sandy Shores Parking Lot Gates
-- PD Front Gate
-- PD Back Gate
-- FR Back Gate (Exit)
-- FR Front Gate (Entrance)
-- Los Santos | FBI Building
-- Entrance Double Doors
{
	objName = 'v_ilev_fibl_door02',
	objCoords  = {x = 106.37, y = -742.69, z = 46.18},
	textCoords = {x = 106.07, y = -743.76, z = 46.18},
	authorizedJobs = { 'police' },
	locked = false,
	distance = 6
},
{
	objName = 'v_ilev_fibl_door01',
	objCoords  = {x = 105.76, y = -746.64, z = 46.18},
	textCoords = {x = 105.71, y = -745.28, z = 46.18},
	authorizedJobs = { 'police' },
	locked = false,
	distance = 6
},

--hospital puertas traseras

	{
		objName = 'hei_prop_heist_cutscene_doorc_r',
		objCoords  = {x = 320.41, y = -559.82, z = 28.74},
		textCoords = {x = 320.41, y = -559.82, z = 28.97},
		authorizedJobs = { 'ambulance' },
		locked = true,
		distance = 6,
		size = 1.5
	},
	{
		objName = 'hei_prop_heist_cutscene_doorc_r',
		objCoords  = {x = 319.35, y = -560.53, z = 28.78},
		textCoords = {x = 319.35, y = -560.53, z = 29.00},
		authorizedJobs = { 'ambulance' },
		locked = true,
		distance = 6,
		size = 1.5
	},
	
	{
		objName = 'v_ilev_cor_offdoora',
		objCoords  = {x = 324.56, y = -591.15, z = 28.78},
		textCoords = {x = 324.30, y = -591.05, z = 29.21},
		authorizedJobs = { 'ambulance' },
		locked = true,
		distance = 6,
		size = 1.5
	},
	
-- mechanic
{
		objName = 'prop_com_ls_door_01',
		objCoords  = {x = -356.0905, y = -134.7714, z = 40.01295},
		textCoords = {x = -356.0905, y = -134.7714, z = 41.01295},
		authorizedJobs = { 'mechanic' },
		locked = true,
		distance = 15,
		size = 2
	},
	{
		objName = 'prop_com_ls_door_01',
		objCoords  = {x = -1145.898, y = -1991.144, z = 14.18357},
		textCoords = {x = -1145.898, y = -1991.144, z = 15.18357},
		authorizedJobs = { 'mechanic' },
		locked = true,
		distance = 15,
		size = 2
	},
	{
		objName = 'v_ilev_carmod3door',
		objCoords  = {x = 1174.656, y = 2644.159, z = 40.50673},
		textCoords = {x = 1174.656, y = 2644.159, z = 41.50673},
		authorizedJobs = { 'mechanic' },
		locked = true,
		distance = 15,
		size = 2
	},
	{
		objName = 'v_ilev_carmod3door',
		objCoords  = {x = 1182.307, y = 2644.166, z = 40.50784},
		textCoords = {x = 1182.307, y = 2644.166, z = 41.50784},
		authorizedJobs = { 'mechanic' },
		locked = true,
		distance = 15,
		size = 2
	},
	{
		objName = 'lr_prop_supermod_door_01',
		objCoords  = {x = -205.55, y = -1310.59, z = 30.31},
		textCoords = {x = -205.55, y = -1310.59, z = 32.31},
		authorizedJobs = { 'tuneador' },
		locked = true,
		distance = 15,
		size = 2
	},
	{
		objName = 'prop_id2_11_gdoor',
		objCoords  = {x = 723.116, y = -1088.831, z = 23.23201},
		textCoords = {x = 723.116, y = -1088.831, z = 24.23201},
		authorizedJobs = { 'mechanic' },
		locked = true,
		distance = 15,
		size = 2
	},
	{
		objName = 'v_ilev_carmod3door',
		objCoords  = {x = 114.3135, y = 6623.233, z = 32.67305},
		textCoords = {x = 114.3135, y = 6623.233, z = 33.67305},
		authorizedJobs = { 'mechanic' },
		locked = true,
		distance = 15,
		size = 2
	},
	{
		objName = 'v_ilev_carmod3door',
		objCoords  = {x = 108.8502, y = 6617.877, z = 32.67305},
		textCoords = {x = 108.8502, y = 6617.877, z = 33.67305},
		authorizedJobs = { 'mechanic' },
		locked = true,
		distance = 15,
		size = 2
	},
	objName = 'v_ilev_roc_door4',
		objCoords  = {x = -564.6336, y = 276.147, z = 83.117},
		textCoords = {x = -564.6336, y =  276.147, z = 83.117},
		authorizedJobs = { 'tequilala' },
		locked = true,
		distance = 15,
		size = 2
	},
	{
		objName = 'v_ilev_rc_door2',
		objCoords  = {x = 108.8502, y = 6617.877, z = 32.67305},
		textCoords = {x = 108.8502, y = 6617.877, z = 33.67305},
		authorizedJobs = { 'mechanic' },
		locked = true,
		distance = 15,
		size = 2
	
},-- BAHAMAS ENTRADA
	{
		objName = 'v_ilev_ph_gendoor006',
		objCoords  = {x = -1393.50, y = -591.15, z = 30.46},
		textCoords = {x = -1393.50, y = -591.15, z = 30.46},
		authorizedJobs = { 'bahamas' },
		locked = true,
		distance = 2.5
	},
	
	{
		objName = 'v_ilev_ph_gendoor006',
		objCoords  = {x = -1391.50, y = -592.73, z = 30.32},
		textCoords = {x = -1391.50, y = -592.73, z = 30.32},
		authorizedJobs = { 'bahamas' },
		locked = true,
		distance = 2.5
	},
		-- TEKILALA DELANTERA
	{
		objName = 'v_ilev_roc_door4',
		objCoords  = {x = -566.17, y = 276.62, z = 83.26},
		textCoords = {x = -566.17, y = 276.62, z = 83.26},
		authorizedJobs = { 'tekilala' },
		locked = false,
		distance = 2.5
	},
		-- TEKILALA TRASERA
	{
		objName = 'v_ilev_roc_door4',
		objCoords  = {x = -561.28, y = 293.50, z = 87.77},
		textCoords = {x = -561.28, y = 293.50, z = 87.77},
		authorizedJobs = { 'tekilala' },
		locked = false,
		distance = 2.5
	},
	-- TEKILALA ZONA BAJA
	{
		objName = 'v_ilev_roc_door2',
		objCoords  = {x = -569.79, y = 293.77, z = 79.32},
		textCoords = {x = -569.79, y = 293.77, z = 79.32},
		authorizedJobs = { 'tekilala' },
		locked = false,
		distance = 2.5
	}