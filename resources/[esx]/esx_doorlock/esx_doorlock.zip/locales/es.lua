Locales ['es'] = {
	['unlocked'] = '~g~Abierta~s~',
	['locked'] = '~r~Cerrada~s~',
	['press_button'] = '[E] %s',
}
