Locales ['en'] = {
	['unlocked'] = '~g~Abierto~s~',
	['locked'] = '~r~Cerrado~s~',
	['press_button'] = '[E] %s',
}
